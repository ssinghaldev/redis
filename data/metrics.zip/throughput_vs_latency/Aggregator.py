import pandas as pd
import sys, getopt, os, glob
from collections import defaultdict


filePattern = 'run_b'
dir = 'normal'
operation = 'READ'
AvgLatency = "AverageLatency"

targets = [10000, 20000, 30000, 40000, 45000]
runs = 3
target_to_files = defaultdict(list)
for target in targets:
    for i in range(1, runs+1):
        target_to_files[target].append(str(i)+"_"+filePattern+"_"+str(target)+".txt")

print(target_to_files)

aggregated_vals = defaultdict(list)
for target in targets:
    files = target_to_files[target]
    for file in files:
        with open(os.path.join(dir, file), "r") as f:
            lines = f.readlines()
            for line in lines:
                fields = line.strip(" \t\n\r").split(",")
                if operation in fields[0] and AvgLatency in fields[1]:
                    aggregated_vals[target].append(fields[2])


print(aggregated_vals)

with open(dir + "/" + operation +"_aggregated_" + filePattern + ".txt", "w") as f:
    for target in targets:
        f.write(str(target) + "\t")
        for val in aggregated_vals[target]:
            f.write(val + "\t")
        f.write("\n")

