import pandas as pd
import sys, getopt, os, glob


inputfile = ''
dir = 'no_workload_2'
port = '17000'
proto = "UDP"

for inputfile in os.listdir(dir):
    if "parsed" in inputfile:
        continue
    parsed_lines = list()
    with open(os.path.join(dir, inputfile), "r") as f:
        lines = f.readlines()
        print(lines[0].split(","))
        for line in lines:
            fields = line.strip().split(",")
            if proto == fields[-3] and (port == fields[1] or port == fields[3]):
                parsed_lines.append(fields)

    total = 0
    with open(dir + "/" + port + "_parsed_" + inputfile, "w") as f:
        #f.writelines(parsed_lines)
        for line in parsed_lines:
            total += int(line[-2])
            f.write(str(line) + "\n")
        f.write("Avg per 5 minutes: " + str(total/300.0))

