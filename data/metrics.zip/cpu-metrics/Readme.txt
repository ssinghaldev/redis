normal: Metrics collected from redis instances
quic: Metrics collected from quic redis instances
cpu_parser: Parses the raw data to the desired state
cpu_making_common_time: Collect the parsed to data under common time