import os
start_time = "1608061103"

dir = "quic"
inputfile = "25_cpu.log"

for inputfile in os.listdir(dir):
    if "parsed" not in inputfile:
        continue
    print("------------processing: ", inputfile, "-------------")
    parsed_lines = list()
    with open(os.path.join(dir, inputfile), "r") as f:
        lines = f.readlines()
        startAppending = False
        for line in lines:
            fields = line.split()
            if fields[0] == start_time:
                startAppending = True
            if startAppending:
                parsed_lines.append((fields[0], fields[1]))

        #print(parsed_lines[:5])

    with open(dir + "/" + "common_" + inputfile, "w") as f:
        #f.writelines(parsed_lines)
        for line in parsed_lines:
            f.write(line[0] + "\t" + line[1] + "\n")