import os

dir = "normal"
inputfile = "25_cpu.log"

for inputfile in os.listdir(dir):
    if "parsed" in inputfile:
        continue
    print("------------processing: ", inputfile, "-------------")
    parsed_lines = list()
    with open(os.path.join(dir, inputfile), "r") as f:
        lines = f.readlines()
        lines = lines[2:]
        #print(lines[:5])
        for line in lines:
            if line[0] == "#" or line == "\n":
                continue
            fields = line.strip(' \t\n\r').split()
            parsed_lines.append((fields[0], fields[6]))

        #print(parsed_lines[:5])

    with open(dir + "/" + "parsed_" + inputfile, "w") as f:
        #f.writelines(parsed_lines)
        for line in parsed_lines:
            f.write(line[0] + "\t" + line[1] + "\n")